# # Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license
# """
# Run prediction on images, videos, directories, globs, YouTube, webcam, streams, etc.

# Usage - sources:
#     $ yolo mode=predict model=yolo11n.pt source=0                               # webcam
#                                                 img.jpg                         # image
#                                                 vid.mp4                         # video
#                                                 screen                          # screenshot
#                                                 path/                           # directory
#                                                 list.txt                        # list of images
#                                                 list.streams                    # list of streams
#                                                 'path/*.jpg'                    # glob
#                                                 'https://youtu.be/LNwODJXcvt4'  # YouTube
#                                                 'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP, TCP stream

# Usage - formats:
#     $ yolo mode=predict model=yolo11n.pt                 # PyTorch
#                               yolo11n.torchscript        # TorchScript
#                               yolo11n.onnx               # ONNX Runtime or OpenCV DNN with dnn=True
#                               yolo11n_openvino_model     # OpenVINO
#                               yolo11n.engine             # TensorRT
#                               yolo11n.mlpackage          # CoreML (macOS-only)
#                               yolo11n_saved_model        # TensorFlow SavedModel
#                               yolo11n.pb                 # TensorFlow GraphDef
#                               yolo11n.tflite             # TensorFlow Lite
#                               yolo11n_edgetpu.tflite     # TensorFlow Edge TPU
#                               yolo11n_paddle_model       # PaddlePaddle
#                               yolo11n.mnn                # MNN
#                               yolo11n_ncnn_model         # NCNN
#                               yolo11n_imx_model          # Sony IMX
#                               yolo11n_rknn_model         # Rockchip RKNN
# """

# import platform
# import re
# import threading
# from pathlib import Path

# import cv2
# import numpy as np
# import torch

# from ultralytics.cfg import get_cfg, get_save_dir
# from ultralytics.data import load_inference_source
# from ultralytics.data.augment import LetterBox, classify_transforms
# from ultralytics.nn.autobackend import AutoBackend
# from ultralytics.utils import DEFAULT_CFG, LOGGER, MACOS, WINDOWS, callbacks, colorstr, ops
# from ultralytics.utils.checks import check_imgsz, check_imshow
# from ultralytics.utils.files import increment_path
# from ultralytics.utils.torch_utils import select_device, smart_inference_mode
# import os
# STREAM_WARNING = """
# WARNING ⚠️ inference results will accumulate in RAM unless `stream=True` is passed, causing potential out-of-memory
# errors for large sources or long-running streams and videos. See https://docs.ultralytics.com/modes/predict/ for help.

# Example:
#     results = model(source=..., stream=True)  # generator of Results objects
#     for r in results:
#         boxes = r.boxes  # Boxes object for bbox outputs
#         masks = r.masks  # Masks object for segment masks outputs
#         probs = r.probs  # Class probabilities for classification outputs
# """


# class BasePredictor:
#     """
#     BasePredictor.

#     A base class for creating predictors.

#     Attributes:
#         args (SimpleNamespace): Configuration for the predictor.
#         save_dir (Path): Directory to save results.
#         done_warmup (bool): Whether the predictor has finished setup.
#         model (nn.Module): Model used for prediction.
#         data (dict): Data configuration.
#         device (torch.device): Device used for prediction.
#         dataset (Dataset): Dataset used for prediction.
#         vid_writer (dict): Dictionary of {save_path: video_writer, ...} writer for saving video output.
#     """

#     def __init__(self, cfg=DEFAULT_CFG, overrides=None, _callbacks=None):
#         """
#         Initializes the BasePredictor class.

#         Args:
#             cfg (str, optional): Path to a configuration file. Defaults to DEFAULT_CFG.
#             overrides (dict, optional): Configuration overrides. Defaults to None.
#         """
#         self.args = get_cfg(cfg, overrides)
#         self.save_dir = get_save_dir(self.args)
#         if self.args.conf is None:
#             self.args.conf = 0.25  # default conf=0.25
#         self.done_warmup = False
#         if self.args.show:
#             self.args.show = check_imshow(warn=True)

#         # Usable if setup is done
#         self.model = None
#         self.data = self.args.data  # data_dict
#         self.imgsz = None
#         self.device = None
#         self.dataset = None
#         self.vid_writer = {}  # dict of {save_path: video_writer, ...}
#         self.plotted_img = None
#         self.source_type = None
#         self.seen = 0
#         self.windows = []
#         self.batch = None
#         self.results = None
#         self.transforms = None
#         self.callbacks = _callbacks or callbacks.get_default_callbacks()
#         self.txt_path = None
#         self._lock = threading.Lock()  # for automatic thread-safe inference
#         callbacks.add_integration_callbacks(self)
#         self.channels = self.args.channels

#     # def preprocess(self, im):
#     #     """
#     #     Prepares input image before inference.
#     #
#     #     Args:
#     #         im (torch.Tensor | List(np.ndarray)): BCHW for tensor, [(HWC) x B] for list.
#     #     """
#     #     not_tensor = not isinstance(im, torch.Tensor)
#     #     if not_tensor:
#     #         im = np.stack(self.pre_transform(im))
#     #         im = im[..., ::-1].transpose((0, 3, 1, 2))  # BGR to RGB, BHWC to BCHW, (n, 3, h, w)
#     #         im = np.ascontiguousarray(im)  # contiguous
#     #         im = torch.from_numpy(im)
#     #
#     #     im = im.to(self.device)
#     #     im = im.half() if self.model.fp16 else im.float()  # uint8 to fp16/32
#     #     if not_tensor:
#     #         im /= 255  # 0 - 255 to 0.0 - 1.0
#     #     return im
#     def preprocess(self, im):
#         """Prepares input image before inference.

#         Args:
#             im (torch.Tensor | List(np.ndarray)): (N, 3, h, w) for tensor, [(h, w, 3) x N] for list.
#         """
#         if not isinstance(im, torch.Tensor):
#             im = np.stack(self.pre_transform(im))
#             # im = im[..., ::-1].transpose((0, 3, 1, 2))  # BGR to RGB, BHWC to BCHW, (n, 3, h, w)
#             # im = np.ascontiguousarray(im)  # contiguous
#             if len(im.shape) < 4:
#                 im = np.expand_dims(im, -1)
#             if (im.shape[3] == 1):
#                 im = np.ascontiguousarray(im.transpose(0, 3, 1, 2))
#             elif (im.shape[3] == 3):
#                 im = im[..., ::-1].transpose((0, 3, 1, 2))  # BGR to RGB, BHWC to BCHW, (n, 3, h, w)
#                 im = np.ascontiguousarray(im)  # contiguous
#             elif (im.shape[3] == 4):
#                 # print("im.shape=", im.shape)
#                 img3c = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, :3, :, :][:, ::-1, :, :])
#                 img1c = im.transpose(0, 3, 1, 2)[:, -1:, :, :]
#                 # print("img3c.shape=",img3c.shape)
#                 # print("img1c.shape=", img1c.shape)

#                 # img1c = np.expand_dims(img1c, 0)
#                 im = np.concatenate((img3c, img1c), axis=1)
#             elif (im.shape[3] == 6):
#                 img3c = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, :3, :, :][:, ::-1, :, :])
#                 img3c2 = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, 3:, :, :][:, ::-1, :, :])
#                 im = np.concatenate((img3c, img3c2), axis=1)
#             else: # Multispectral
#                 im = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, ::-1, :, :])  # BGR to RGB, BHWC to BCHW, (n, 3, h, w)
#             im = torch.from_numpy(im)

#         # NOTE: assuming im with (b, 3, h, w) if it's a tensor
#         img = im.to(self.device)
#         img = img.half() if self.model.fp16 else img.float()  # uint8 to fp16/32
#         img /= 255  # 0 - 255 to 0.0 - 1.0
#         return img

#     # 2025 01 05

#     def inference(self, im, *args, **kwargs):
#         """Runs inference on a given image using the specified model and arguments."""
#         visualize = (
#             increment_path(self.save_dir / Path(self.batch[0][0]).stem, mkdir=True)
#             if self.args.visualize and (not self.source_type.tensor)
#             else False
#         )
#         return self.model(im, augment=self.args.augment, visualize=visualize, embed=self.args.embed, *args, **kwargs)

#     def pre_transform(self, im):
#         """
#         Pre-transform input image before inference.

#         Args:
#             im (List(np.ndarray)): (N, 3, h, w) for tensor, [(h, w, 3) x N] for list.

#         Returns:
#             (list): A list of transformed images.
#         """
#         same_shapes = len({x.shape for x in im}) == 1
#         letterbox = LetterBox(
#             self.imgsz,
#             auto=same_shapes and (self.model.pt or (getattr(self.model, "dynamic", False) and not self.model.imx)),
#             stride=self.model.stride,
#         )
#         return [letterbox(image=x) for x in im]

#     def postprocess(self, preds, img, orig_imgs):
#         """Post-processes predictions for an image and returns them."""
#         return preds

#     def __call__(self, source=None, model=None, stream=False, *args, **kwargs):
#         """Performs inference on an image or stream."""
#         self.stream = stream
#         if stream:
#             return self.stream_inference(source, model, *args, **kwargs)
#         else:
#             return list(self.stream_inference(source, model, *args, **kwargs))  # merge list of Result into one

#     def predict_cli(self, source=None, model=None):
#         """
#         Method used for Command Line Interface (CLI) prediction.

#         This function is designed to run predictions using the CLI. It sets up the source and model, then processes
#         the inputs in a streaming manner. This method ensures that no outputs accumulate in memory by consuming the
#         generator without storing results.

#         Note:
#             Do not modify this function or remove the generator. The generator ensures that no outputs are
#             accumulated in memory, which is critical for preventing memory issues during long-running predictions.
#         """
#         gen = self.stream_inference(source, model)
#         for _ in gen:  # sourcery skip: remove-empty-nested-block, noqa
#             pass

#     def setup_source(self, source):
#         """Sets up source and inference mode."""
#         self.imgsz = check_imgsz(self.args.imgsz, stride=self.model.stride, min_dim=2)  # check image size
#         self.transforms = (
#             getattr(
#                 self.model.model,
#                 "transforms",
#                 classify_transforms(self.imgsz[0], crop_fraction=self.args.crop_fraction),
#             )
#             if self.args.task == "classify"
#             else None
#         )
#         self.dataset = load_inference_source(
#             source=source,
#             batch=self.args.batch,
#             vid_stride=self.args.vid_stride,
#             buffer=self.args.stream_buffer,
#             use_simotm=self.args.use_simotm,
#             imgsz=self.args.imgsz,
#             pairs_rgb_ir=self.args.pairs_rgb_ir,
#         )
#         self.source_type = self.dataset.source_type
#         if not getattr(self, "stream", True) and (
#             self.source_type.stream
#             or self.source_type.screenshot
#             or len(self.dataset) > 1000  # many images
#             or any(getattr(self.dataset, "video_flag", [False]))
#         ):  # videos
#             LOGGER.warning(STREAM_WARNING)
#         self.vid_writer = {}

#     @smart_inference_mode()
#     def stream_inference(self, source=None, model=None, *args, **kwargs):
#         """Streams real-time inference on camera feed and saves results to file."""
#         if self.args.verbose:
#             LOGGER.info("")

#         # Setup model
#         if not self.model:
#             self.setup_model(model)

#         with self._lock:  # for thread-safe inference
#             # Setup source every time predict is called
#             self.setup_source(source if source is not None else self.args.source)

#             # Check if save_dir/ label file exists
#             if self.args.save or self.args.save_txt:
#                 (self.save_dir / "labels" if self.args.save_txt else self.save_dir).mkdir(parents=True, exist_ok=True)

#             # Warmup model
#             if not self.done_warmup:
#                 # self.model.warmup(imgsz=(1 if self.model.pt or self.model.triton else self.dataset.bs, 3, *self.imgsz))
#                 self.model.warmup(imgsz=(1 if self.model.pt or self.model.triton else self.dataset.bs, self.channels, *self.imgsz))
#                 self.done_warmup = True

#             self.seen, self.windows, self.batch = 0, [], None
#             profilers = (
#                 ops.Profile(device=self.device),
#                 ops.Profile(device=self.device),
#                 ops.Profile(device=self.device),
#             )
#             self.run_callbacks("on_predict_start")
#             for self.batch in self.dataset:
#                 self.run_callbacks("on_predict_batch_start")
#                 paths, im0s, s = self.batch

#                 # Preprocess
#                 with profilers[0]:
#                     im = self.preprocess(im0s)

#                 # Inference
#                 with profilers[1]:
#                     preds = self.inference(im, *args, **kwargs)
#                     if self.args.embed:
#                         yield from [preds] if isinstance(preds, torch.Tensor) else preds  # yield embedding tensors
#                         continue

#                 # Postprocess
#                 with profilers[2]:
#                     self.results = self.postprocess(preds, im, im0s)
#                 self.run_callbacks("on_predict_postprocess_end")

#                 # Visualize, save, write results
#                 n = len(im0s)
#                 for i in range(n):
#                     self.seen += 1
#                     self.results[i].speed = {
#                         "preprocess": profilers[0].dt * 1e3 / n,
#                         "inference": profilers[1].dt * 1e3 / n,
#                         "postprocess": profilers[2].dt * 1e3 / n,
#                     }
#                     if self.args.verbose or self.args.save or self.args.save_txt or self.args.show:
#                         s[i] += self.write_results(i, Path(paths[i]), im, s)

#                 # Print batch results
#                 if self.args.verbose:
#                     LOGGER.info("\n".join(s))

#                 self.run_callbacks("on_predict_batch_end")
#                 yield from self.results

#         # Release assets
#         for v in self.vid_writer.values():
#             if isinstance(v, cv2.VideoWriter):
#                 v.release()

#         # Print final results
#         if self.args.verbose and self.seen:
#             t = tuple(x.t / self.seen * 1e3 for x in profilers)  # speeds per image
#             LOGGER.info(
#                 f"Speed: %.1fms preprocess, %.1fms inference, %.1fms postprocess per image at shape "
#                 f"{(min(self.args.batch, self.seen), 3, *im.shape[2:])}" % t
#             )
#         if self.args.save or self.args.save_txt or self.args.save_crop:
#             nl = len(list(self.save_dir.glob("labels/*.txt")))  # number of labels
#             s = f"\n{nl} label{'s' * (nl > 1)} saved to {self.save_dir / 'labels'}" if self.args.save_txt else ""
#             LOGGER.info(f"Results saved to {colorstr('bold', self.save_dir)}{s}")
#         self.run_callbacks("on_predict_end")

#     def setup_model(self, model, verbose=True):
#         """Initialize YOLO model with given parameters and set it to evaluation mode."""
#         self.model = AutoBackend(
#             weights=model or self.args.model,
#             device=select_device(self.args.device, verbose=verbose),
#             dnn=self.args.dnn,
#             data=self.args.data,
#             fp16=self.args.half,
#             batch=self.args.batch,
#             fuse=True,
#             verbose=verbose,
#         )

#         self.device = self.model.device  # update device
#         self.args.half = self.model.fp16  # update half
#         self.model.eval()

#     def write_results(self, i, p, im, s):
#         """Write inference results to a file or directory."""
#         string = ""  # print string
#         if len(im.shape) == 3:
#             im = im[None]  # expand for batch dim
#         if self.source_type.stream or self.source_type.from_img or self.source_type.tensor:  # batch_size >= 1
#             string += f"{i}: "
#             frame = self.dataset.count
#         else:
#             match = re.search(r"frame (\d+)/", s[i])
#             frame = int(match[1]) if match else None  # 0 if frame undetermined

#         self.txt_path = self.save_dir / "labels" / (p.stem + ("" if self.dataset.mode == "image" else f"_{frame}"))
#         string += "{:g}x{:g} ".format(*im.shape[2:])
#         result = self.results[i]
#         result.save_dir = self.save_dir.__str__()  # used in other locations
#         string += f"{result.verbose()}{result.speed['inference']:.1f}ms"

#         # Add predictions to image
#         if self.args.save or self.args.show:
#             self.plotted_img = result.plot(
#                 line_width=self.args.line_width,
#                 boxes=self.args.show_boxes,
#                 conf=self.args.show_conf,
#                 labels=self.args.show_labels,
#                 im_gpu=None if self.args.retina_masks else im[i],
#                 use_simotm=self.args.use_simotm,  # 2025-01-05
#             )

#         # Save results
#         if self.args.save_txt:
#             result.save_txt(f"{self.txt_path}.txt", save_conf=self.args.save_conf)
#         if self.args.save_crop:
#             result.save_crop(save_dir=self.save_dir / "crops", file_name=self.txt_path.stem)
#         if self.args.show:
#             self.show(str(p))
#         if self.args.save:
#             self.save_predicted_images(str(self.save_dir / p.name), frame)

#         return string

#     def save_predicted_images(self, save_path="", frame=0):
#         """Save video predictions as mp4 at specified path."""
#         im = self.plotted_img

#         # Save videos and streams
#         if self.dataset.mode in {"stream", "video"}:
#             fps = self.dataset.fps if self.dataset.mode == "video" else 30
#             frames_path = f"{save_path.split('.', 1)[0]}_frames/"
#             if save_path not in self.vid_writer:  # new video
#                 if self.args.save_frames:
#                     Path(frames_path).mkdir(parents=True, exist_ok=True)
#                 suffix, fourcc = (".mp4", "avc1") if MACOS else (".avi", "WMV2") if WINDOWS else (".avi", "MJPG")
#                 self.vid_writer[save_path] = cv2.VideoWriter(
#                     filename=str(Path(save_path).with_suffix(suffix)),
#                     fourcc=cv2.VideoWriter_fourcc(*fourcc),
#                     fps=fps,  # integer required, floats produce error in MP4 codec
#                     frameSize=(im.shape[1], im.shape[0]),  # (width, height)
#                 )

#             # Save video
#             self.vid_writer[save_path].write(im)
#             if self.args.save_frames:
#                 # cv2.imwrite(f"{frames_path}{frame}.jpg", im)
#                 self.save_image_mutichannel(im, f"{frames_path}{frame}.jpg")

#         # Save images
#         else:
#             # cv2.imwrite(str(Path(save_path).with_suffix(".jpg")), im)  # save to JPG for best support
#             self.save_image_mutichannel(im, str(Path(save_path).with_suffix(".jpg")))

#     # def show(self, p=""):
#     #     """Display an image in a window using the OpenCV imshow function."""
#     #     im = self.plotted_img
#     #     if platform.system() == "Linux" and p not in self.windows:
#     #         self.windows.append(p)
#     #         cv2.namedWindow(p, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)  # allow window resize (Linux)
#     #         cv2.resizeWindow(p, im.shape[1], im.shape[0])  # (width, height)
#     #     cv2.imshow(p, im)
#     #     cv2.waitKey(300 if self.dataset.mode == "image" else 1)  # 1 millisecond

#     def show(self, p=""):
#         """Display an image in a window using OpenCV imshow()."""
#         im = self.plotted_img
#         channels = im.shape[2] if len(im.shape) == 3 else 1  # 获取通道数
#         try:
#             if channels  in [1, 3]:  # 如果是3通道图像，直接显示
#                 if platform.system() == "Linux" and p not in self.windows:
#                     self.windows.append(p)
#                     cv2.namedWindow(p, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)  # allow window resize (Linux)
#                     cv2.resizeWindow(p, im.shape[1], im.shape[0])  # (width, height)
#                 cv2.imshow(p, im)
#                 cv2.waitKey(300 if self.dataset.mode == "image" else 1)  # 1 millisecond

#             elif channels in [4, 6]:  # 如果是4通道或6通道图像，分离显示
#                 if channels == 4:
#                     im_rgb = im[:, :, :3]  # 前三个通道
#                     im_extra = im[:, :, 3:4]  # 第四个通道
#                 elif channels == 6:
#                     im_rgb = im[:, :, :3]  # 前三个通道
#                     im_extra = im[:, :, 3:6]  # 后三个通道

#                 # 显示前三个通道
#                 window_name_rgb = f"{p}_RGB"
#                 if platform.system() == "Linux" and window_name_rgb not in self.windows:
#                     self.windows.append(window_name_rgb)
#                     cv2.namedWindow(window_name_rgb, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
#                     cv2.resizeWindow(window_name_rgb, im_rgb.shape[1], im_rgb.shape[0])
#                 cv2.imshow(window_name_rgb, im_rgb)

#                 # 显示额外的通道
#                 window_name_extra = f"{p}_Extra"
#                 if platform.system() == "Linux" and window_name_extra not in self.windows:
#                     self.windows.append(window_name_extra)
#                     cv2.namedWindow(window_name_extra, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
#                     cv2.resizeWindow(window_name_extra, im_extra.shape[1], im_extra.shape[0])
#                 cv2.imshow(window_name_extra, im_extra)

#                 cv2.waitKey(300 if self.dataset.mode == "image" else 1)  # 1 millisecond

#             else:  # 如果通道数不符合预期，打印警告信息
#                 print(f"Warning: Image with {channels} channels is not supported for display.")
#         except:
#             print(f"Warning: Image with {channels} channels is not supported for display.")

#     def run_callbacks(self, event: str):
#         """Runs all registered callbacks for a specific event."""
#         for callback in self.callbacks.get(event, []):
#             callback(self)

#     def add_callback(self, event: str, func):
#         """Add callback."""
#         self.callbacks[event].append(func)


#     def save_image_mutichannel(self, im, save_path):
#         channels = im.shape[2]  # 获取通道数

#         # 获取文件扩展名，不区分大小写
#         file_extension = os.path.splitext(save_path)[1].lower()
#         # print(file_extension)
#         if channels == 3 or channels == 1:
#             cv2.imwrite(save_path, im)
#         elif channels == 6:
#             # 假设6通道的图像由2个RGB合并而来
#             # 分开RGB
#             im1 = im[:, :, :3]  # 第一部分RGB
#             im2 = im[:, :, 3:]  # 第二部分RGB

#             # 分别保存
#             cv2.imwrite(save_path.replace(file_extension, '_part1' + file_extension), im1)
#             cv2.imwrite(save_path.replace(file_extension, '_part2' + file_extension), im2)

#         elif channels == 4:
#             # 假设4通道的图像是RGB和灰度图
#             rgb = im[:, :, :3]  # RGB部分
#             gray = im[:, :, 3:]  # 灰度图部分

#             # 分别保存
#             cv2.imwrite(save_path.replace(file_extension, '_part1' + file_extension), rgb)
#             cv2.imwrite(save_path.replace(file_extension, '_part2' + file_extension), gray)

#         else:
#             cv2.imwrite(str(Path(save_path).with_suffix(".jpg")), im[:, :, :3])
#             # 有需要的话，可以通过下列方式保存其他通道   If desired, additional channels can be saved as follows
#             # cv2.imwrite(save_path.replace(file_extension, '_part2' + ".jpg")), im[:, :, 4:5])  # 保存第四通道 其余通道类似  Save channel 4 The rest of the channels are similar






#####-----------改---------------###
# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license
"""
Run prediction on images, videos, directories, globs, YouTube, webcam, streams, etc.

Usage - sources:
    $ yolo mode=predict model=yolo11n.pt source=0                               # webcam
                                                img.jpg                         # image
                                                vid.mp4                         # video
                                                screen                          # screenshot
                                                path/                           # directory
                                                list.txt                        # list of images
                                                list.streams                    # list of streams
                                                'path/*.jpg'                    # glob
                                                'https://youtu.be/LNwODJXcvt4'  # YouTube
                                                'rtsp://example.com/media.mp4'  # RTSP, RTMP, HTTP, TCP stream

Usage - formats:
    $ yolo mode=predict model=yolo11n.pt                 # PyTorch
                              yolo11n.torchscript        # TorchScript
                              yolo11n.onnx               # ONNX Runtime or OpenCV DNN with dnn=True
                              yolo11n_openvino_model     # OpenVINO
                              yolo11n.engine             # TensorRT
                              yolo11n.mlpackage          # CoreML (macOS-only)
                              yolo11n_saved_model        # TensorFlow SavedModel
                              yolo11n.pb                 # TensorFlow GraphDef
                              yolo11n.tflite             # TensorFlow Lite
                              yolo11n_edgetpu.tflite     # TensorFlow Edge TPU
                              yolo11n_paddle_model       # PaddlePaddle
                              yolo11n.mnn                # MNN
                              yolo11n_ncnn_model         # NCNN
                              yolo11n_imx_model          # Sony IMX
                              yolo11n_rknn_model         # Rockchip RKNN
"""

import platform
import re
import threading
from pathlib import Path

import cv2
import numpy as np
import torch

from ultralytics.cfg import get_cfg, get_save_dir
from ultralytics.data import load_inference_source
from ultralytics.data.augment import LetterBox, classify_transforms
from ultralytics.nn.autobackend import AutoBackend
from ultralytics.utils import DEFAULT_CFG, LOGGER, MACOS, WINDOWS, callbacks, colorstr, ops
from ultralytics.utils.checks import check_imgsz, check_imshow
from ultralytics.utils.files import increment_path
from ultralytics.utils.torch_utils import select_device, smart_inference_mode
import os

STREAM_WARNING = """
WARNING ⚠️ inference results will accumulate in RAM unless `stream=True` is passed, causing potential out-of-memory
errors for large sources or long-running streams and videos. See https://docs.ultralytics.com/modes/predict/ for help.

Example:
    results = model(source=..., stream=True)  # generator of Results objects
    for r in results:
        boxes = r.boxes  # Boxes object for bbox outputs
        masks = r.masks  # Masks object for segment masks outputs
        probs = r.probs  # Class probabilities for classification outputs
"""


class BasePredictor:
    """
    BasePredictor.

    A base class for creating predictors.

    Attributes:
        args (SimpleNamespace): Configuration for the predictor.
        save_dir (Path): Directory to save results.
        done_warmup (bool): Whether the predictor has finished setup.
        model (nn.Module): Model used for prediction.
        data (dict): Data configuration.
        device (torch.device): Device used for prediction.
        dataset (Dataset): Dataset used for prediction.
        vid_writer (dict): Dictionary of {save_path: video_writer, ...} writer for saving video output.
    """

    def __init__(self, cfg=DEFAULT_CFG, overrides=None, _callbacks=None):
        """
        Initializes the BasePredictor class.

        Args:
            cfg (str, optional): Path to a configuration file. Defaults to DEFAULT_CFG.
            overrides (dict, optional): Configuration overrides. Defaults to None.
        """
        self.args = get_cfg(cfg, overrides)
        self.save_dir = get_save_dir(self.args)
        if self.args.conf is None:
            self.args.conf = 0.25  # default conf=0.25
        self.done_warmup = False
        if self.args.show:
            self.args.show = check_imshow(warn=True)

        # Usable if setup is done
        self.model = None
        self.data = self.args.data  # data_dict
        self.imgsz = None
        self.device = None
        self.dataset = None
        self.vid_writer = {}  # dict of {save_path: video_writer, ...}
        self.plotted_img = None
        self.source_type = None
        self.seen = 0
        self.windows = []
        self.batch = None
        self.results = None
        self.transforms = None
        self.callbacks = _callbacks or callbacks.get_default_callbacks()
        self.txt_path = None
        self._lock = threading.Lock()  # for automatic thread-safe inference
        callbacks.add_integration_callbacks(self)
        self.channels = self.args.channels

    def preprocess(self, im):
        """Prepares input image before inference.

        Args:
            im (torch.Tensor | List[np.ndarray]): (N, C, h, w) for tensor, [(h, w, C) x N] for list.
        """
        if not isinstance(im, torch.Tensor):
            im = np.stack(self.pre_transform(im))

            if len(im.shape) < 4:
                im = np.expand_dims(im, -1)

            if im.shape[3] == 1:
                im = np.ascontiguousarray(im.transpose(0, 3, 1, 2))

            elif im.shape[3] == 3:
                im = im[..., ::-1].transpose((0, 3, 1, 2))  # BGR to RGB, BHWC to BCHW
                im = np.ascontiguousarray(im)

            elif im.shape[3] == 4:
                img3c = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, :3, :, :][:, ::-1, :, :])
                img1c = im.transpose(0, 3, 1, 2)[:, -1:, :, :]
                im = np.concatenate((img3c, img1c), axis=1)

            elif im.shape[3] == 6:
                img3c = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, :3, :, :][:, ::-1, :, :])
                img3c2 = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, 3:, :, :][:, ::-1, :, :])
                im = np.concatenate((img3c, img3c2), axis=1)

            elif im.shape[3] == 9:
                # RGB6C9C: visible 3通道 + infrared 6通道
                # visible 由 cv2 读入，为 BGR，需要转为 RGB；
                # infrared 是 .npy 的6通道特征，不反转通道顺序。
                im_chw = im.transpose(0, 3, 1, 2)
                img3c = np.ascontiguousarray(im_chw[:, :3, :, :][:, ::-1, :, :])
                img6c = np.ascontiguousarray(im_chw[:, 3:, :, :])
                im = np.concatenate((img3c, img6c), axis=1)

            else:  # Multispectral
                im = np.ascontiguousarray(im.transpose(0, 3, 1, 2)[:, ::-1, :, :])

            im = torch.from_numpy(im)

        img = im.to(self.device)
        img = img.half() if self.model.fp16 else img.float()
        img /= 255
        return img

    def inference(self, im, *args, **kwargs):
        """Runs inference on a given image using the specified model and arguments."""
        visualize = (
            increment_path(self.save_dir / Path(self.batch[0][0]).stem, mkdir=True)
            if self.args.visualize and (not self.source_type.tensor)
            else False
        )
        return self.model(im, augment=self.args.augment, visualize=visualize, embed=self.args.embed, *args, **kwargs)

    def pre_transform(self, im):
        """
        Pre-transform input image before inference.

        Args:
            im (List[np.ndarray]): [(h, w, C) x N] for list.

        Returns:
            (list): A list of transformed images.
        """
        same_shapes = len({x.shape for x in im}) == 1
        letterbox = LetterBox(
            self.imgsz,
            auto=same_shapes and (self.model.pt or (getattr(self.model, "dynamic", False) and not self.model.imx)),
            stride=self.model.stride,
        )
        return [letterbox(image=x) for x in im]

    def postprocess(self, preds, img, orig_imgs):
        """Post-processes predictions for an image and returns them."""
        return preds

    def __call__(self, source=None, model=None, stream=False, *args, **kwargs):
        """Performs inference on an image or stream."""
        self.stream = stream
        if stream:
            return self.stream_inference(source, model, *args, **kwargs)
        else:
            return list(self.stream_inference(source, model, *args, **kwargs))

    def predict_cli(self, source=None, model=None):
        """
        Method used for Command Line Interface (CLI) prediction.
        """
        gen = self.stream_inference(source, model)
        for _ in gen:
            pass

    def setup_source(self, source):
        """Sets up source and inference mode."""
        self.imgsz = check_imgsz(self.args.imgsz, stride=self.model.stride, min_dim=2)
        self.transforms = (
            getattr(
                self.model.model,
                "transforms",
                classify_transforms(self.imgsz[0], crop_fraction=self.args.crop_fraction),
            )
            if self.args.task == "classify"
            else None
        )
        self.dataset = load_inference_source(
            source=source,
            batch=self.args.batch,
            vid_stride=self.args.vid_stride,
            buffer=self.args.stream_buffer,
            use_simotm=self.args.use_simotm,
            imgsz=self.args.imgsz,
            pairs_rgb_ir=self.args.pairs_rgb_ir,
        )
        self.source_type = self.dataset.source_type
        if not getattr(self, "stream", True) and (
            self.source_type.stream
            or self.source_type.screenshot
            or len(self.dataset) > 1000
            or any(getattr(self.dataset, "video_flag", [False]))
        ):
            LOGGER.warning(STREAM_WARNING)
        self.vid_writer = {}

    @smart_inference_mode()
    def stream_inference(self, source=None, model=None, *args, **kwargs):
        """Streams real-time inference on camera feed and saves results to file."""
        if self.args.verbose:
            LOGGER.info("")

        # Setup model
        if not self.model:
            self.setup_model(model)

        with self._lock:
            # Setup source every time predict is called
            self.setup_source(source if source is not None else self.args.source)

            # Check if save_dir/ label file exists
            if self.args.save or self.args.save_txt:
                (self.save_dir / "labels" if self.args.save_txt else self.save_dir).mkdir(parents=True, exist_ok=True)

            # Warmup model
            if not self.done_warmup:
                self.model.warmup(imgsz=(1 if self.model.pt or self.model.triton else self.dataset.bs, self.channels, *self.imgsz))
                self.done_warmup = True

            self.seen, self.windows, self.batch = 0, [], None
            profilers = (
                ops.Profile(device=self.device),
                ops.Profile(device=self.device),
                ops.Profile(device=self.device),
            )
            self.run_callbacks("on_predict_start")

            for self.batch in self.dataset:
                self.run_callbacks("on_predict_batch_start")
                paths, im0s, s = self.batch

                # Preprocess
                with profilers[0]:
                    im = self.preprocess(im0s)

                # Inference
                with profilers[1]:
                    preds = self.inference(im, *args, **kwargs)
                    if self.args.embed:
                        yield from [preds] if isinstance(preds, torch.Tensor) else preds
                        continue

                # Postprocess
                with profilers[2]:
                    self.results = self.postprocess(preds, im, im0s)

                self.run_callbacks("on_predict_postprocess_end")

                # Visualize, save, write results
                n = len(im0s)
                for i in range(n):
                    self.seen += 1
                    self.results[i].speed = {
                        "preprocess": profilers[0].dt * 1e3 / n,
                        "inference": profilers[1].dt * 1e3 / n,
                        "postprocess": profilers[2].dt * 1e3 / n,
                    }
                    if self.args.verbose or self.args.save or self.args.save_txt or self.args.show:
                        s[i] += self.write_results(i, Path(paths[i]), im, s)

                # Print batch results
                if self.args.verbose:
                    LOGGER.info("\n".join(s))

                self.run_callbacks("on_predict_batch_end")
                yield from self.results

        # Release assets
        for v in self.vid_writer.values():
            if isinstance(v, cv2.VideoWriter):
                v.release()

        # Print final results
        if self.args.verbose and self.seen:
            t = tuple(x.t / self.seen * 1e3 for x in profilers)
            LOGGER.info(
                f"Speed: %.1fms preprocess, %.1fms inference, %.1fms postprocess per image at shape "
                f"{(min(self.args.batch, self.seen), self.channels, *im.shape[2:])}" % t
            )

        if self.args.save or self.args.save_txt or self.args.save_crop:
            nl = len(list(self.save_dir.glob("labels/*.txt")))
            s = f"\n{nl} label{'s' * (nl > 1)} saved to {self.save_dir / 'labels'}" if self.args.save_txt else ""
            LOGGER.info(f"Results saved to {colorstr('bold', self.save_dir)}{s}")

        self.run_callbacks("on_predict_end")

    def setup_model(self, model, verbose=True):
        """Initialize YOLO model with given parameters and set it to evaluation mode."""
        self.model = AutoBackend(
            weights=model or self.args.model,
            device=select_device(self.args.device, verbose=verbose),
            dnn=self.args.dnn,
            data=self.args.data,
            fp16=self.args.half,
            batch=self.args.batch,
            fuse=True,
            verbose=verbose,
        )

        self.device = self.model.device
        self.args.half = self.model.fp16
        self.model.eval()

    def write_results(self, i, p, im, s):
        """Write inference results to a file or directory."""
        string = ""
        if len(im.shape) == 3:
            im = im[None]

        if self.source_type.stream or self.source_type.from_img or self.source_type.tensor:
            string += f"{i}: "
            frame = self.dataset.count
        else:
            match = re.search(r"frame (\d+)/", s[i])
            frame = int(match[1]) if match else None

        self.txt_path = self.save_dir / "labels" / (p.stem + ("" if self.dataset.mode == "image" else f"_{frame}"))
        string += "{:g}x{:g} ".format(*im.shape[2:])

        result = self.results[i]
        result.save_dir = self.save_dir.__str__()
        string += f"{result.verbose()}{result.speed['inference']:.1f}ms"

        # Add predictions to image
        if self.args.save or self.args.show:
            # 只在 RGB6C9C 模式下，将画框底图改为 visible 的前3通道。
            # 其它模式不传 img，保持原项目逻辑不变。
            plot_img = None

            if getattr(self.args, "use_simotm", None) == "RGB6C9C":
                plot_img = result.orig_img

                if isinstance(plot_img, np.ndarray) and plot_img.ndim == 3 and plot_img.shape[2] >= 9:
                    # 9通道 = visible 3通道 + infrared 6通道
                    # 画框只画在 visible 图像上，避免 OpenCV 对9通道图像画框报错。
                    plot_img = np.ascontiguousarray(plot_img[:, :, :3])

                    # 和 .npy 拼接后 dtype 可能变成 float，这里转回 uint8，方便 OpenCV 画框和保存。
                    if plot_img.dtype != np.uint8:
                        if plot_img.max() <= 1.0:
                            plot_img = plot_img * 255.0
                        plot_img = np.clip(plot_img, 0, 255).astype(np.uint8)
                else:
                    plot_img = None

            if plot_img is not None:
                self.plotted_img = result.plot(
                    img=plot_img,
                    line_width=self.args.line_width,
                    boxes=self.args.show_boxes,
                    conf=self.args.show_conf,
                    labels=self.args.show_labels,
                    im_gpu=None if self.args.retina_masks else im[i],
                    use_simotm=self.args.use_simotm,
                )
            else:
                self.plotted_img = result.plot(
                    line_width=self.args.line_width,
                    boxes=self.args.show_boxes,
                    conf=self.args.show_conf,
                    labels=self.args.show_labels,
                    im_gpu=None if self.args.retina_masks else im[i],
                    use_simotm=self.args.use_simotm,
                )

        # Save results
        if self.args.save_txt:
            result.save_txt(f"{self.txt_path}.txt", save_conf=self.args.save_conf)

        if self.args.save_crop:
            result.save_crop(save_dir=self.save_dir / "crops", file_name=self.txt_path.stem)

        if self.args.show:
            self.show(str(p))

        if self.args.save:
            self.save_predicted_images(str(self.save_dir / p.name), frame)

        return string

    def save_predicted_images(self, save_path="", frame=0):
        """Save video predictions as mp4 at specified path."""
        im = self.plotted_img

        # Save videos and streams
        if self.dataset.mode in {"stream", "video"}:
            fps = self.dataset.fps if self.dataset.mode == "video" else 30
            frames_path = f"{save_path.split('.', 1)[0]}_frames/"

            if save_path not in self.vid_writer:
                if self.args.save_frames:
                    Path(frames_path).mkdir(parents=True, exist_ok=True)

                suffix, fourcc = (".mp4", "avc1") if MACOS else (".avi", "WMV2") if WINDOWS else (".avi", "MJPG")
                self.vid_writer[save_path] = cv2.VideoWriter(
                    filename=str(Path(save_path).with_suffix(suffix)),
                    fourcc=cv2.VideoWriter_fourcc(*fourcc),
                    fps=fps,
                    frameSize=(im.shape[1], im.shape[0]),
                )

            self.vid_writer[save_path].write(im)

            if self.args.save_frames:
                self.save_image_mutichannel(im, f"{frames_path}{frame}.jpg")

        # Save images
        else:
            self.save_image_mutichannel(im, str(Path(save_path).with_suffix(".jpg")))

    def show(self, p=""):
        """Display an image in a window using OpenCV imshow()."""
        im = self.plotted_img
        channels = im.shape[2] if len(im.shape) == 3 else 1

        try:
            if channels in [1, 3]:
                if platform.system() == "Linux" and p not in self.windows:
                    self.windows.append(p)
                    cv2.namedWindow(p, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
                    cv2.resizeWindow(p, im.shape[1], im.shape[0])
                cv2.imshow(p, im)
                cv2.waitKey(300 if self.dataset.mode == "image" else 1)

            elif channels in [4, 6]:
                if channels == 4:
                    im_rgb = im[:, :, :3]
                    im_extra = im[:, :, 3:4]
                elif channels == 6:
                    im_rgb = im[:, :, :3]
                    im_extra = im[:, :, 3:6]

                window_name_rgb = f"{p}_RGB"
                if platform.system() == "Linux" and window_name_rgb not in self.windows:
                    self.windows.append(window_name_rgb)
                    cv2.namedWindow(window_name_rgb, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
                    cv2.resizeWindow(window_name_rgb, im_rgb.shape[1], im_rgb.shape[0])
                cv2.imshow(window_name_rgb, im_rgb)

                window_name_extra = f"{p}_Extra"
                if platform.system() == "Linux" and window_name_extra not in self.windows:
                    self.windows.append(window_name_extra)
                    cv2.namedWindow(window_name_extra, cv2.WINDOW_NORMAL | cv2.WINDOW_KEEPRATIO)
                    cv2.resizeWindow(window_name_extra, im_extra.shape[1], im_extra.shape[0])
                cv2.imshow(window_name_extra, im_extra)

                cv2.waitKey(300 if self.dataset.mode == "image" else 1)

            else:
                print(f"Warning: Image with {channels} channels is not supported for display.")

        except Exception:
            print(f"Warning: Image with {channels} channels is not supported for display.")

    def run_callbacks(self, event: str):
        """Runs all registered callbacks for a specific event."""
        for callback in self.callbacks.get(event, []):
            callback(self)

    def add_callback(self, event: str, func):
        """Add callback."""
        self.callbacks[event].append(func)

    def save_image_mutichannel(self, im, save_path):
        channels = im.shape[2]

        file_extension = os.path.splitext(save_path)[1].lower()

        if channels == 3 or channels == 1:
            cv2.imwrite(save_path, im)

        elif channels == 6:
            im1 = im[:, :, :3]
            im2 = im[:, :, 3:]

            cv2.imwrite(save_path.replace(file_extension, "_part1" + file_extension), im1)
            cv2.imwrite(save_path.replace(file_extension, "_part2" + file_extension), im2)

        elif channels == 4:
            rgb = im[:, :, :3]
            gray = im[:, :, 3:]

            cv2.imwrite(save_path.replace(file_extension, "_part1" + file_extension), rgb)
            cv2.imwrite(save_path.replace(file_extension, "_part2" + file_extension), gray)

        else:
            cv2.imwrite(str(Path(save_path).with_suffix(".jpg")), im[:, :, :3])